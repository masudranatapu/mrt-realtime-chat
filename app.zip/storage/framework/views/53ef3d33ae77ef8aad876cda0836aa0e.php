<?php $__env->startSection('content'); ?>
    <div class="container">
        <chat-component :user="<?php echo e($user); ?>" :auth="<?php echo e(Auth::user()); ?>"></chat-component>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mrtchatrealtime\resources\views/chat.blade.php ENDPATH**/ ?>